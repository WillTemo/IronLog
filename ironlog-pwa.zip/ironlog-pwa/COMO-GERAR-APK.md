# 📦 Como Transformar o IronLog em APK

## Método Recomendado: PWABuilder (grátis, sem programar)

### Pré-requisitos
Você precisa hospedar os arquivos na internet antes de gerar o APK.
A opção mais fácil e gratuita é o **GitHub Pages** ou **Netlify**.

---

## Passo 1 — Hospedar os arquivos

### Opção A: Netlify (mais fácil, arraste e solte)
1. Acesse **https://app.netlify.com/drop**
2. Arraste a pasta `ironlog-pwa/` inteira para a área indicada
3. Aguarde o upload — você receberá uma URL como `https://nome-aleatorio.netlify.app`
4. Anote essa URL — você vai precisar no Passo 2

### Opção B: GitHub Pages (gratuito e permanente)
1. Crie uma conta em **https://github.com**
2. Crie um repositório público chamado `ironlog`
3. Faça upload de todos os arquivos da pasta `ironlog-pwa/`
4. Vá em Settings → Pages → Source: `main branch / root`
5. Sua URL será: `https://seu-usuario.github.io/ironlog`

---

## Passo 2 — Gerar o APK com PWABuilder

1. Acesse **https://www.pwabuilder.com**
2. Cole a URL do seu site no campo de busca e clique em **Start**
3. Aguarde a análise (deve dar pontuação alta pois o app está configurado corretamente)
4. Clique em **Package For Stores**
5. Escolha **Android**
6. Clique em **Generate Package**
7. Baixe o arquivo `.apk` gerado

---

## Passo 3 — Instalar o APK no celular

1. No celular, vá em **Configurações → Segurança**
2. Ative **"Instalar apps de fontes desconhecidas"** (ou "Instalar apps desconhecidos")
3. Transfira o `.apk` para o celular (por cabo, Google Drive, WhatsApp, etc.)
4. Abra o arquivo `.apk` no celular
5. Toque em **Instalar**

> **Observação:** No Android 8+, você precisa conceder permissão ao app específico que abre o APK (ex: Gerenciador de Arquivos, Chrome, etc.)

---

## Sobre os dados

- Os dados ficam salvos no **IndexedDB** do dispositivo — muito mais persistente que localStorage
- Os dados **não são perdidos** ao fechar o app
- **Backup:** Não há sincronização com nuvem — se desinstalar o app ou trocar de celular, os dados ficam no aparelho antigo

---

## Alternativa sem hospedar: instalar como PWA diretamente

Se não quiser gerar o APK, você pode instalar o app direto do Chrome:

1. Abra o arquivo `index.html` em um servidor local ou hospede-o
2. No Chrome Android, toque no menu (⋮) → **"Adicionar à tela inicial"**
3. O app aparecerá na tela inicial igual a um app nativo

---

## Estrutura dos arquivos

```
ironlog-pwa/
├── index.html       ← App principal
├── manifest.json    ← Configuração PWA
├── sw.js            ← Service Worker (cache offline)
└── icons/
    ├── icon-192.png ← Ícone do app
    └── icon-512.png ← Ícone grande (Play Store)
```
